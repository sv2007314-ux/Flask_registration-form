from flask import Flask, render_template
from forms import RegistrationForm
from models import db, User

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'

db.init_app(app)

@app.route('/', methods=['GET', 'POST'])
def home():
    form = RegistrationForm()

    if form.validate_on_submit():
        user = User(name=form.name.data)
        db.session.add(user)
        db.session.commit()
        return render_template("success.html",name=form.name.data)

    return render_template("register.html", form=form)
if __name__ == "__main__":
    app.run(debug=True)